# AI Roles High-Frequency Master Sheet

## How to use this sheet

This is a single preparation sheet for:

- AI Engineer
- Machine Learning Engineer
- Generative AI Engineer
- LLM Application Engineer
- ML Platform / AI Infrastructure Engineer
- Applied Scientist Engineer
- Forward-Deployed Engineer
- Solutions Engineer for AI products
- AI Product Engineer

It is a high-signal global preparation map, not a guarantee of exact interview questions or an offer. Teams differ by level, product, research depth, coding language, and business domain.

For every answer, use this sequence:

1. Define the term or goal.
2. Explain the intuition.
3. State the trade-off.
4. Give a production example.
5. Mention how you would measure success.
6. Mention one failure mode and mitigation.

# Part 1: Role map

## AI Engineer

Builds reliable software around models: APIs, data pipelines, evaluation, retrieval, tools, deployment, monitoring, and product integration.

## ML Engineer

Owns data, features, training, evaluation, deployment, inference, monitoring, and model lifecycle.

## Generative AI / LLM Engineer

Builds applications using language, vision, audio, or multimodal models, including prompting, RAG, tool use, agents, evaluation, safety, and serving.

## AI Infrastructure Engineer

Optimizes distributed training, inference, model serving, GPU utilization, memory, batching, scheduling, networking, and reliability.

## FDE / Solutions Engineer

Translates ambiguous customer problems into safe working systems, integrates APIs and data, prototypes quickly, debugs production issues, and communicates with technical and non-technical stakeholders.

# Part 2: Machine learning fundamentals

## Q1. What is supervised learning?

**Answer:** Supervised learning learns a mapping from inputs to labeled targets. Classification predicts discrete labels; regression predicts continuous values. The training objective minimizes a loss on training data, while validation data helps select models and hyperparameters. The real goal is generalization to future data, not memorization.

**Depth points:** Check label quality, leakage, distribution shift, calibration, class imbalance, and whether the offline metric reflects the business outcome.

## Q2. What is overfitting?

**Answer:** Overfitting occurs when a model captures noise or accidental patterns in the training set and performs poorly on unseen data. Causes include excessive model capacity, noisy features, leakage, insufficient data, or over-training.

**Mitigations:** More representative data, regularization, early stopping, data augmentation, simpler models, cross-validation, feature selection, and careful leakage checks.

## Q3. Bias versus variance?

**Answer:** Bias is systematic error from an overly restrictive model; variance is sensitivity to the particular training sample. High bias underfits, while high variance overfits. The useful solution is not always a more complex model: improve data, regularization, feature quality, and validation design.

## Q4. Train, validation, and test split?

**Answer:** Training fits parameters; validation selects models, features, thresholds, and hyperparameters; the test set is held back for a final unbiased estimate. Reusing the test set repeatedly turns it into a validation set and makes the estimate optimistic.

**Time-aware data:** For temporal prediction, split by time rather than random shuffling to prevent future information leaking into the past.

## Q5. What is data leakage?

**Answer:** Leakage occurs when information unavailable at prediction time influences a feature, label, split, or preprocessing step. Examples include fitting normalization on all data, using a post-outcome field, or randomly splitting users when the same user appears in train and test.

**Fix:** Define the prediction timestamp and enforce feature availability at that time.

## Q6. Precision, recall, and F1?

**Answer:** Precision is the fraction of predicted positives that are correct. Recall is the fraction of actual positives found. F1 is their harmonic mean. The threshold should be selected based on the cost of false positives and false negatives, not because 0.5 is a default.

## Q7. ROC-AUC versus PR-AUC?

**Answer:** ROC-AUC measures ranking quality across thresholds and can look strong on highly imbalanced data. PR-AUC focuses on positive-class precision and recall and is often more informative when positives are rare.

## Q8. What is calibration?

**Answer:** A calibrated probability means that among predictions near 0.8, approximately 80% are positive. Calibration matters when probabilities drive decisions, prioritization, risk, or resource allocation. Check reliability diagrams and calibration error, not only ranking metrics.

## Q9. How do you handle class imbalance?

**Answer:** First understand whether the labels and sampling reflect production. Options include class weights, threshold tuning, careful resampling, focal loss, anomaly methods, and collecting better positives. Always evaluate on the real production distribution and report per-class metrics.

## Q10. How do you debug a model-quality regression?

**Answer:** Freeze a known-good baseline, reproduce on a fixed dataset, compare data distributions and labels, inspect feature freshness and schema, check preprocessing and threshold changes, slice by cohort, and compare error examples. Roll back or disable the feature when user harm is possible.

# Part 3: Deep learning and transformers

## Q11. What is a neural network learning?

**Answer:** It learns parameters that transform inputs into predictions through differentiable layers. Backpropagation applies the chain rule to compute gradients, and an optimizer updates parameters to reduce the loss.

**Depth points:** Initialization, normalization, activation functions, gradient stability, batch size, learning rate, regularization, and data scale all affect training.

## Q12. What is an embedding?

**Answer:** An embedding maps an object such as text, an image, or a user into a dense vector space where useful relationships are represented geometrically. Similarity requires an appropriate metric and normalization strategy. Embeddings are not universal truth; their quality depends on training data, task, language, and domain.

## Q13. Explain attention.

**Answer:** Attention lets each token assign weights to other tokens when constructing its contextual representation. Queries describe what a token seeks, keys describe what other tokens offer, and values carry the information. Scaled dot-product attention is approximately `softmax(QK^T / sqrt(d))V`.

**Trade-off:** Standard self-attention has quadratic token interaction cost, which motivates efficient attention, chunking, sparse methods, and retrieval.

## Q14. Why are positional encodings needed?

**Answer:** Self-attention alone is permutation-invariant, so the model needs position information to distinguish word order. This can be added through learned or fixed embeddings, relative positions, or rotary position representations.

## Q15. Encoder, decoder, and encoder-decoder models?

**Answer:** Encoders build representations useful for understanding and classification. Decoder-only models generate autoregressively by predicting the next token. Encoder-decoder models encode an input and decode an output, which is natural for translation and transformation tasks.

## Q16. What is a token and why does it matter?

**Answer:** A token is a model vocabulary unit, often a subword rather than a whole word. Tokenization affects context length, cost, latency, multilingual behavior, and truncation. Production systems should measure token usage and explicitly preserve important content under context limits.

## Q17. What causes hallucination?

**Answer:** A language model optimizes likely continuation, not guaranteed truth. Hallucination can come from missing knowledge, ambiguous prompts, retrieval errors, unsupported inference, stale training data, or pressure to answer instead of abstain.

**Mitigations:** Retrieval with access control, citations, structured validation, tool verification, constrained outputs, calibrated abstention, human escalation, and evaluation on adversarial cases.

# Part 4: LLM application engineering

## Q18. What is RAG?

**Answer:** Retrieval-augmented generation retrieves relevant external information at request time and supplies it to a model before generation. It separates knowledge updates from model retraining and can provide citations, but it does not automatically guarantee correctness or authorization.

**Pipeline:** Ingest, parse, clean, chunk, attach metadata, embed, index, retrieve, filter permissions, rerank, construct bounded context, generate, validate, and log quality signals.

## Q19. How do you choose chunk size?

**Answer:** Chunk size should preserve enough context to answer a question while remaining specific enough for accurate retrieval. Evaluate different sizes against retrieval recall, answer groundedness, duplication, token cost, and document structure. Use headings, tables, page numbers, and source IDs as metadata.

## Q20. Dense, sparse, and hybrid retrieval?

**Answer:** Dense retrieval captures semantic similarity through embeddings. Sparse retrieval such as BM25 handles exact terms, identifiers, and rare words well. Hybrid retrieval combines both and often improves robustness across natural language and exact-match queries.

## Q21. Why use reranking?

**Answer:** A first-stage retriever efficiently generates candidates; a reranker uses a more expensive relevance model to order a smaller candidate set. This improves precision under a fixed context budget, but adds latency and cost.

## Q22. How do you evaluate RAG?

**Answer:** Evaluate retrieval and generation separately. Retrieval metrics include recall, precision, MRR, and NDCG against labeled evidence. Generation metrics include groundedness, citation correctness, answer completeness, refusal quality, and human preference. Segment by language, document type, tenant, question difficulty, and permission level.

## Q23. How do you prevent unauthorized retrieval?

**Answer:** Carry tenant and document permissions into the index and enforce authorization before context construction. The model prompt is not a security boundary. Test cross-tenant, revoked-access, deleted-document, and indirect-instruction cases.

## Q24. What is prompt injection?

**Answer:** Prompt injection is an attempt by user input or retrieved content to override intended instructions or cause unsafe behavior. Treat user and retrieved content as untrusted data, isolate instructions, restrict tools by explicit policy, validate tool arguments, and require confirmation for high-impact actions.

## Q25. What is fine-tuning versus RAG?

**Answer:** RAG is usually better for changing factual knowledge, citations, permissions, and document-specific information. Fine-tuning is useful for behavior, style, structured patterns, or domain adaptation when high-quality examples exist. Fine-tuning does not reliably provide a secure or updatable knowledge base.

## Q26. What is supervised fine-tuning?

**Answer:** The model is trained on input-output examples to improve desired behavior. The quality, diversity, correctness, and licensing of examples matter more than simply increasing volume. Hold out representative evaluation data and watch for memorization and regressions.

## Q27. What is preference optimization?

**Answer:** Preference methods train or adjust a model using ranked alternatives or preference signals. They can improve helpfulness and style but may optimize the evaluator rather than the user’s real goal. Use diverse evaluation, safety checks, and task-specific metrics.

## Q28. How do you manage context windows?

**Answer:** Do not blindly append history. Use relevance filtering, hierarchical summaries, retrieval, recency rules, token budgeting, structured state, and explicit deletion or retention policies. Preserve user goals, constraints, unresolved tasks, and source references rather than every previous token.

## Q29. Streaming versus non-streaming generation?

**Answer:** Streaming improves perceived latency and enables early cancellation, but partial output complicates moderation, retries, structured parsing, and billing. Define what happens when a stream fails after partial output and distinguish time-to-first-token from total completion time.

## Q30. How do you reduce LLM cost?

**Answer:** Measure cost by workflow and tenant. Reduce unnecessary context, cache embeddings and safe repeated requests, batch offline work, route simple requests to smaller models, limit output tokens, use structured retrieval, and avoid retries that duplicate expensive work. Never trade away privacy or quality without measurement.

# Part 5: Agents and tool use

## Q31. What is an AI agent?

**Answer:** An agent is a system that uses a model to plan or select actions, call tools, observe results, and continue toward a goal. The production system must constrain the action space, validate inputs and outputs, manage state, enforce permissions, and stop safely.

## Q32. How do you make tool use safe?

**Answer:** Use allowlisted tools, least-privilege credentials, typed schemas, input validation, output size limits, timeouts, sandboxing, audit logs, human confirmation for irreversible actions, and independent policy checks. Never allow arbitrary model-generated code or unrestricted network access by default.

## Q33. When should you not use an agent?

**Answer:** Avoid an agent when a deterministic workflow, search query, rules engine, or ordinary API is sufficient. Agents add latency, cost, nondeterminism, and new failure modes. Use them where flexible planning materially improves the task and where actions can be bounded and evaluated.

## Q34. How do you handle agent loops?

**Answer:** Set step, time, token, and cost budgets. Detect repeated states, enforce deadlines, record traces, and define a safe terminal state. Return a partial result or escalate rather than retrying forever.

# Part 6: Model serving and infrastructure

## Q35. Batch versus online inference?

**Answer:** Batch inference maximizes throughput and is suitable when latency is flexible. Online inference minimizes response time but needs capacity management, autoscaling, admission control, and tail-latency protection.

## Q36. What is batching?

**Answer:** Batching combines requests to improve hardware utilization, but waiting for a batch increases latency. Dynamic batching uses a maximum batch size or short wait window and should be tuned using throughput, p95/p99 latency, memory, and queue depth.

## Q37. What is quantization?

**Answer:** Quantization uses lower-precision representations to reduce memory and improve speed. It can cause accuracy degradation, especially for sensitive layers or tasks. Evaluate quality and numerical stability on representative workloads.

## Q38. What is a model-serving SLO?

**Answer:** Define availability, error rate, time to first token, completion latency, throughput, quality, and cost. A model service can be technically available while producing poor answers, so quality and safety need service-level monitoring too.

## Q39. How do you protect p99 latency?

**Answer:** Set deadlines, isolate workloads, limit queues, use admission control, monitor tail latency, avoid unbounded retries, and provide graceful degradation. Averages hide overloaded users; p95 and p99 reveal the user experience.

## Q40. How do you design model fallback?

**Answer:** Classify failures, define a fallback quality contract, and choose a substitute based on capability, privacy, latency, and cost. Test schema compatibility, tool behavior, safety, and answer quality. A fallback should be observable and rate-limited to prevent cascading overload.

# Part 7: MLOps and production

## Q41. What is a reproducible ML pipeline?

**Answer:** Version code, data snapshots, feature definitions, labels, configuration, model artifacts, environment, and evaluation results. Record lineage so a prediction can be traced to the model and data used.

## Q42. What should you monitor after deployment?

**Answer:** Service metrics include availability, latency, throughput, errors, queue depth, and resource use. Model metrics include drift, feature health, calibration, quality, slice performance, feedback, and safety. For LLMs also track token usage, retrieval quality, groundedness, refusal rate, and user corrections.

## Q43. What is data drift?

**Answer:** Data drift means the input distribution changes. It may be harmless or may indicate that the model is becoming unreliable. Compare distributions, investigate affected slices, connect drift to labels when available, and define retraining or rollback triggers.

## Q44. Safe model rollout?

**Answer:** Validate offline, shadow traffic, canary a small cohort, compare to a baseline, enforce guardrails, use feature flags, monitor rollback criteria, and retain the previous model. For high-risk flows, require human review or staged permissions.

# Part 8: Security, privacy, and responsible AI

## Q45. Authentication versus authorization?

**Answer:** Authentication verifies identity; authorization determines what that identity may access or do. In AI systems, both must be enforced in the application and data layers, not delegated to the model.

## Q46. How do you handle PII?

**Answer:** Minimize collection, classify data, restrict access, encrypt in transit and at rest, redact where possible, define retention and deletion, audit access, and prevent sensitive content from entering prompts or logs unnecessarily.

## Q47. What is tenant isolation?

**Answer:** Tenant isolation ensures one customer cannot access another customer’s data, indexes, cache entries, prompts, logs, or model outputs. Enforce tenant identity at every storage and retrieval boundary and test cache-key, vector-filter, and deletion failures.

## Q48. How do you respond to a harmful output?

**Answer:** Protect the user first, preserve relevant evidence, classify the failure, disable or constrain the risky path if necessary, notify the right owners, and fix the underlying prompt, data, model, policy, or tool boundary. Measure recurrence after the fix.

# Part 9: FDE and solutions scenarios

## Q49. Customer wants a chatbot over private documents

**Answer approach:** Clarify users, workflows, document sources, permissions, freshness, languages, success metrics, and unacceptable answers. Build ingestion with source ACLs, hybrid retrieval, citations, evaluation sets, human escalation, and a limited pilot.

## Q50. Customer says the AI is inaccurate

**Answer approach:** Ask for representative failures. Separate retrieval failure, context construction failure, generation failure, and evaluation disagreement. Measure each stage, fix the highest-leverage cause, and agree on a measurable acceptance threshold.

## Q51. Customer requests an unsafe shortcut

**Answer:** Explain the security or privacy risk in business terms, propose a safe alternative, document the decision, and escalate when necessary. Never bypass authorization to meet a deadline.

## Q52. Prototype must ship in two weeks

**Answer:** Define a thin vertical slice, use real but controlled data, set explicit non-goals, instrument from day one, create a small evaluation set, pilot with selected users, and report production gaps rather than hiding them.

## Q53. Production integration duplicates customer records

**Answer:** Check retries, timeouts, client behavior, missing idempotency keys, race conditions, and webhook delivery semantics. Add a durable idempotency record keyed by the business event, make processing transactional where possible, and design replay and reconciliation.

## Q54. How do you communicate bad news?

**Answer:** State impact, facts, uncertainty, options, recommendation, owner, and next update time. Do not hide risk behind technical vocabulary. A customer should understand what works, what does not, and what decision is needed.

# Part 10: Coding and practical AI exercises

1. Implement LRU cache.
2. Implement TTL cache.
3. Implement token-bucket rate limiter.
4. Implement sliding-window rate limiter.
5. Implement idempotent event processor.
6. Implement bounded worker queue.
7. Implement retry with backoff and jitter.
8. Implement circuit breaker.
9. Implement Trie autocomplete.
10. Implement top-K stream counter.
11. Merge timestamped event streams.
12. Chunk documents by token budget and sentence boundary.
13. Build a permission-aware document retriever.
14. Build a ranked retrieval evaluator.
15. Build a prompt-version registry.
16. Build a conversation truncation policy.
17. Build a simple feature-store interface.
18. Build a log-based latency and error analyzer.
19. Build a webhook signature verifier.
20. Build a small model-router abstraction.

For each exercise, explain:

- API and input contract.
- State and persistence.
- Concurrency assumptions.
- Failure and retry behavior.
- Security and privacy.
- Tests and metrics.
- Complexity and scaling limit.

# Part 11: Behavioral questions

Prepare a specific STAR answer for:

1. Tell me about your hardest technical project.
2. Tell me about a production incident.
3. Tell me about a failure.
4. Tell me about conflict with a teammate.
5. Tell me about an ambiguous customer request.
6. Tell me about a time you influenced without authority.
7. Tell me about reducing cost or latency.
8. Tell me about a privacy or security decision.
9. Tell me about learning a difficult technology.
10. Tell me about a project that changed direction.
11. Tell me about a deadline you could not meet.
12. Tell me about mentoring someone.

A strong answer includes your personal decision, the trade-off, measurable result, and lesson. Avoid vague claims such as “we improved performance” without a before-and-after measure.

# Part 12: Final high-bar checklist

You are well prepared when you can:

- Explain ML fundamentals without memorized definitions.
- Derive attention and describe its scaling trade-off.
- Design RAG with permissions, evaluation, and observability.
- Explain when RAG, fine-tuning, or a deterministic workflow is appropriate.
- Design safe tool use and prevent agent loops.
- Discuss model serving, batching, latency, cost, and fallback.
- Write medium-level algorithms under time pressure.
- Write practical SQL with joins and window functions.
- Debug a production failure with hypotheses and evidence.
- Discuss concurrency, distributed systems, and API reliability.
- Explain privacy, tenant isolation, and responsible AI.
- Turn an ambiguous customer request into a measurable delivery plan.
- Give concise behavioral stories with measurable impact.

## Final answer formula

> My first assumption is ____. The user outcome is ____. The simplest correct design is ____. The main bottleneck or risk is ____. I would measure ____. I would protect against failure by ____. The trade-off is ____, and I would revisit it when ____.
